import Link from "next/link";
import { Button } from "./_components/Button";
import Header from "./_components/Header";

export default function AuthPage() {
  return (
    <div className="flex h-screen w-screen flex-col justify-between bg-blue-950 py-44">
      <Header src="/images/logo.svg">RunFlowVR</Header>
      <div className="flex flex-col items-center justify-center">
        <Button>
          <Link href="/sign-up">Sign Up</Link>
        </Button>
        <span className="py-4 text-white">OR</span>
        <Button>
          <Link href="/log-in">Log In</Link>
        </Button>
      </div>
    </div>
  );
}
