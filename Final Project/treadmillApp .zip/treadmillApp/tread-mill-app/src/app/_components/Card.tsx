import Link from "next/link";
import { FaPlay } from "react-icons/fa";
import { cn } from "~/lib/utils";

type CardProps = {
  title: string;
  timer: string;
  heartBeat: string;
  speed: string;
  href?: string;
  className?: string;
};

const Card = ({
  title,
  timer,
  heartBeat,
  speed,
  href,
  className,
}: CardProps) => {
  const card = (
    <div
      className={cn(
        "flex flex-col gap-2 rounded-md bg-red-600 p-4 text-white",
        className,
      )}
    >
      <div className="flex justify-between text-xl font-medium">
        <span>{title}</span>
        <span>{timer}</span>
      </div>
      <div className="flex justify-between">
        <div className="flex justify-start gap-6 text-xs">
          <span>Heart beat: {heartBeat}</span>
          <span>Speed: {speed}</span>
        </div>
        <FaPlay />
      </div>
    </div>
  );

  return href ? <Link href={href}>{card}</Link> : card;
};

export default Card;
