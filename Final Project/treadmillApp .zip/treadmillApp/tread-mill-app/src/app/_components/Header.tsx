import Image from "next/image";
import { cn } from "~/lib/utils";

type HeaderProps = {
  src: string;
  className?: string;
  children: React.ReactNode;
};

const Header = ({ src, className, children }: HeaderProps) => {
  return (
    <header
      className={cn("flex flex-col items-center justify-center", className)}
    >
      <Image src={src} width={100} height={100} alt="Header Image" />
      <div className="p-6 text-center text-xl font-bold leading-none tracking-wide text-white">
        {children}
      </div>
    </header>
  );
};

export default Header;
