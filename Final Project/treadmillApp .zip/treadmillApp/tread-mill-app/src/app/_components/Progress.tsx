type ProgressProps = {
  percent: number;
};

const Progress = ({ percent }: ProgressProps) => {
  const radius = 100;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percent / 100) * circumference;
  const currentAngle = (percent / 100) * Math.PI * 2 - Math.PI;
  const handleX = 113 + radius * Math.cos(currentAngle);
  const handleY = 113 + radius * Math.sin(currentAngle);

  return (
    <svg height="226" width="226" className="rounded-full bg-cyan-900">
      <circle
        stroke="red"
        fill="transparent"
        strokeWidth="5"
        r={radius}
        cx="113"
        cy="113"
      />
      <circle
        stroke="white"
        fill="transparent"
        strokeWidth="5"
        strokeDasharray={circumference + " " + circumference}
        style={{
          strokeDashoffset,
          transform: "rotate(180deg)",
          transformOrigin: "center",
        }}
        r={radius}
        cx="113"
        cy="113"
      />
      <circle cx={handleX} cy={handleY} r="8" fill="white" />
      <rect
        x="63"
        y="63"
        width="100"
        height="100"
        fill="red"
        rx="50%"
        ry="50%"
      />
      <image href="/icons/foot.svg" width={58} height={58} x="84" y="84" />
    </svg>
  );
};

export default Progress;
