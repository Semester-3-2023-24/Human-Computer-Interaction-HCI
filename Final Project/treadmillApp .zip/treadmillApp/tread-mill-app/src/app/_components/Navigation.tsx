import Image from "next/image";
import Link from "next/link";
import { cn } from "~/lib/utils";
import { DrawerTrigger } from "./Drawer";

type NavigationProps = {
  src: string;
  className?: string;
  href?: string;
  children?: React.ReactNode;
};

const Navigation = ({ src, href, className, children }: NavigationProps) => {
  return (
    <div className={cn("flex justify-between px-7 py-8", className)}>
      {href ? (
        <Link href={href}>
          <Image src={src} width={25} height={19} alt="Navigation Icon" />
        </Link>
      ) : (
        <DrawerTrigger>
          <Image src={src} width={25} height={19} alt="Navigation Icon" />
        </DrawerTrigger>
      )}
      <span className="font-bold text-white">{children}</span>
      <span />
    </div>
  );
};

export default Navigation;
