import Link from "next/link";
import { Button } from "../_components/Button";
import Header from "../_components/Header";
import { Input } from "../_components/Input";
import Navigation from "../_components/Navigation";

export default function LogInPage() {
  return (
    <main className="flex h-screen w-screen flex-col bg-blue-950">
      <Navigation href="/" src="/icons/chevron-left.svg" />
      <div className="flex h-full flex-col justify-between py-8">
        <div className="flex flex-col justify-between pt-12">
          <Header src="/images/user.svg">Log In</Header>
        </div>
        <section className="mx-auto flex w-72 flex-col justify-between gap-8">
          <Input type="email" placeholder="Email" />
          <Input type="password" placeholder="Password" />
        </section>
        <section className="flex flex-col items-center justify-center">
          <Button>
            <Link href="/home">Log In</Link>
          </Button>
          <span className="pt-4 text-white">Forgot Password?</span>
        </section>
        <footer className="flex justify-center">
          <Link href="/sing-up" className="text-white">
            Don&apos;t have an account? Sign up!
          </Link>
        </footer>
      </div>
    </main>
  );
}
