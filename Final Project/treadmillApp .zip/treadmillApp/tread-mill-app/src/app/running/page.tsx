"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { Button } from "../_components/Button";
import Progress from "../_components/Progress";

export default function RunningPage() {
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<
    "running" | "paused" | "finished" | null
  >(null);

  const timeout = setTimeout(() => {
    if (status === "running")
      if (progress < 100) setProgress(progress + 1);
      else {
        setStatus("finished");
        clearTimeout(timeout);
      }
  }, 100);

  return (
    <>
      <Link href="/home">
        <Image
          className="absolute left-6 top-8 h-[19px] w-[25px]"
          src="icons/chevron-left.svg"
          width={25}
          height={19}
          alt="Navigation Icon"
        />
      </Link>
      <div className="flex h-screen w-screen flex-col items-center justify-between bg-red-800 pb-8 pt-20 text-white">
        <h1 className="text-3xl font-bold">Running</h1>
        <div className="flex flex-col items-center justify-center">
          <Progress percent={progress} />
          <span className="pt-2">
            {Math.round((progress / 100) * 20)} / 20km
          </span>
        </div>
        {status === "finished" ? (
          <span className="text-2xl font-medium">Workout complete</span>
        ) : (
          <Button
            className="bg-cyan-900"
            onClick={() => {
              if (!status) setStatus("running");
              else if (status === "running") setStatus("paused");
              else if (status === "paused") setStatus("running");
            }}
          >
            {
              {
                null: "Start",
                running: "Pause",
                paused: "Resume",
              }[String(status)]
            }
          </Button>
        )}
      </div>
    </>
  );
}
