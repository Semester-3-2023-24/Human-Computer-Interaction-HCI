import Link from "next/link";
import { Button } from "../_components/Button";
import Header from "../_components/Header";
import { Input } from "../_components/Input";
import Navigation from "../_components/Navigation";

export default function SignUpPage() {
  return (
    <main className="flex h-screen w-screen flex-col bg-blue-950">
      <Navigation href="/" src="/icons/chevron-left.svg" />
      <div className="flex h-full flex-col justify-between py-8">
        <div className="flex flex-col justify-between pt-12">
          <Header src="/images/user.svg">Sign Up</Header>
        </div>
        <section className="mx-auto flex w-72 flex-col justify-between gap-8">
          <Input type="text" placeholder="Name" />
          <Input type="email" placeholder="Email" />
          <Input type="password" placeholder="Password" />
        </section>
        <section className="flex flex-col items-center justify-center">
          <Button>
            <Link href="/home">Sign Up</Link>
          </Button>
          <span className="py-4 text-white">OR</span>
          <span className="text-white">Facebook | Google+</span>
        </section>
        <footer className="flex justify-center">
          <Link href="/log-in" className="text-white">
            Already have an account? Log in.
          </Link>
        </footer>
      </div>
    </main>
  );
}
