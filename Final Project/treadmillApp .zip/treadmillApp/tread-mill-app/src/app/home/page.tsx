"use client";

import dayjs from "dayjs";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { cn } from "~/lib/utils";
import { Button } from "../_components/Button";
import Card from "../_components/Card";
import { Drawer, DrawerContent, DrawerFooter } from "../_components/Drawer";
import Navigation from "../_components/Navigation";

const days: Record<number, string> = {
  0: "Sun",
  1: "Mon",
  2: "Tue",
  3: "Wed",
  4: "Thu",
  5: "Fri",
  6: "Sat",
};

export default function HomePage() {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [currentDay, setCurrentDay] = useState(dayjs().day());

  return (
    <main className="flex h-screen w-screen flex-col bg-blue-950">
      <Drawer
        direction="left"
        open={isDrawerOpen}
        onOpenChange={(open) => setIsDrawerOpen(open)}
      >
        <Navigation src="/icons/menu.svg">Home</Navigation>
        <DrawerContent>
          <div className="flex flex-col items-center justify-center gap-4">
            <Button
              className="justify-between rounded-none border-b border-red-600 bg-transparent px-4 text-base font-normal"
              asChild
            >
              <Link href="/profile">
                <span>My Profile</span>
                <Image
                  className="text-red-600"
                  src="/icons/chevron-right.svg"
                  width={8}
                  height={14}
                  alt="Navigation Icon"
                />
              </Link>
            </Button>
            <Button
              className="justify-between rounded-none border-b border-red-600 bg-transparent px-4 text-base font-normal"
              onClick={() => setIsDrawerOpen(false)}
            >
              <span>Home</span>
              <Image
                className="text-red-600"
                src="/icons/chevron-right.svg"
                width={8}
                height={14}
                alt="Navigation Icon"
              />
            </Button>
            <Button
              className="justify-between rounded-none border-b border-red-600 bg-transparent px-4 text-base font-normal"
              asChild
            >
              <Link href="/marathons">
                <span>Marathons</span>
                <Image
                  className="text-red-600"
                  src="/icons/chevron-right.svg"
                  width={8}
                  height={14}
                  alt="Navigation Icon"
                />
              </Link>
            </Button>
            <Button
              className="justify-between rounded-none border-b border-red-600 bg-transparent px-4 text-base font-normal"
              asChild
            >
              <Link href="/settings">
                <span>Settings</span>
                <Image
                  className="text-red-600"
                  src="/icons/chevron-right.svg"
                  width={8}
                  height={14}
                  alt="Navigation Icon"
                />
              </Link>
            </Button>
          </div>
          <DrawerFooter>
            <Button
              className="justify-between rounded-none bg-transparent px-4 text-base font-normal"
              asChild
            >
              <Link href="/">
                <span>Log Out</span>
                <Image
                  className="text-red-600"
                  src="/icons/chevron-right.svg"
                  width={8}
                  height={14}
                  alt="Navigation Icon"
                />
              </Link>
            </Button>
          </DrawerFooter>
        </DrawerContent>
        <header className="flex w-full gap-3 px-4">
          {Object.keys(days).map((day: string) => {
            const parsedDay = Number(day);

            return (
              <button
                key={day}
                onClick={() => setCurrentDay(parsedDay)}
                className={cn(
                  "flex h-14 flex-1 items-center justify-center rounded-md text-white",
                  {
                    "bg-cyan-900": currentDay !== parsedDay,
                    "bg-red-600": currentDay === parsedDay,
                  },
                )}
              >
                <div className="flex flex-col justify-between">
                  <span>{days[parsedDay]}</span>
                  <span>{dayjs().day(parsedDay).date()}</span>
                </div>
              </button>
            );
          })}
        </header>
        <div className="flex flex-col">
          <span className="px-4 pt-6 text-white">Statistics</span>
          <div className="relative mt-2 h-[206px] w-full">
            <Image
              src="/images/chart.svg"
              layout="fill"
              objectFit="cover"
              alt="Chart"
            />
          </div>
        </div>
        <div className="flex justify-between border-b border-t border-cyan-900 px-6 py-4 font-medium text-white">
          <span>Km:</span>
          <span>Time 00 : 00</span>
        </div>
        <div className="flex flex-col gap-4 px-6 py-4">
          <Card
            href="/running"
            title="Walk"
            timer="00 : 00"
            heartBeat="000"
            speed="000"
          />
          <Card
            href="/running"
            title="Slow Run"
            timer="00 : 00"
            heartBeat="000"
            speed="000"
          />
          <Card
            href="/running"
            title="Fast Run"
            timer="00 : 00"
            heartBeat="000"
            speed="000"
          />
        </div>
      </Drawer>
    </main>
  );
}
